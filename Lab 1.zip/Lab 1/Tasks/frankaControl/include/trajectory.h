#pragma once

#include <Eigen/Dense>
#include <iostream>

/****************************  
Function to calculate a circular trajectory in xy-plane
*****************************/
void circularTrajectory(double t, const Eigen::Vector3d &x0, Eigen::Vector3d &x_d, Eigen::Vector3d &v_d, Eigen::Vector3d &a_d);