#include "trajectory.h"

void circularTrajectory(double t, const Eigen::Vector3d &x0, Eigen::Vector3d &x_d, Eigen::Vector3d &v_d, Eigen::Vector3d &a_d) {

    double R = 0.05;
    double L = 2*M_PI*R;

    double v_max = 0.1;
    double a_max = 0.3;

    double Tm = v_max/a_max;
    double T  = (L*a_max + v_max*v_max) / (a_max*v_max);
    
    double S, dS, ddS;

    if (t >= 0 && t <= Tm) {
        S = a_max * t * t / 2;
        dS = a_max * t;
        ddS = a_max;
    } else if (t >= Tm && t <= (T - Tm)) {
        S = v_max * t - v_max * v_max / (2 * a_max);
        dS = v_max;
        ddS = 0;
    } else if (t >= (T - Tm) && t <= T) {
        S = -a_max * (t - T) * (t - T) / 2 + v_max * T - v_max * v_max / a_max;
        dS = -a_max * (t - T);
        ddS = -a_max;
    } else {
        S = L;
        dS = 0;
        ddS = 0;
    }

    x_d[0] = (x0[0] - R) + R * cos(S/R);
    x_d[1] = x0[1] + R * sin(S/R);
    x_d[2] = x0[2];

    v_d[0] = -1 * dS * sin(S/R);
    v_d[1] = dS * cos(S/R);
    v_d[2] = 0;

    a_d[0] = -1/R * ddS * sin(S/R) - 1/R * dS * dS * cos(S/R);
    a_d[1] = 1/R * ddS * cos(S/R) - 1/R * dS * dS * sin(S/R);
    a_d[2] = 0;
}