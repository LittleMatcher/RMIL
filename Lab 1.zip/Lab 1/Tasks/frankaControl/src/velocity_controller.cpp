
#include <franka/duration.h>
#include <franka/exception.h>
#include <franka/model.h>
#include <franka/robot.h>

#include <Eigen/Core>
#include <Eigen/Dense>
#include <array>
#include <cmath>
#include <functional>
#include <iostream>

#include "trajectory.h"


int main(int argc, char** argv) {
    // Check whether the required arguments were passed
    if (argc != 2) {
        std::cerr << "Usage: " << argv[0] << " <robot-hostname>" << std::endl;
        return -1;
    }

    // Control Gains
    const double k = ...;

    Eigen::Matrix3d K_p;

    K_p << k, 0, 0,
           0, k, 0,
           0, 0, k;

    // Initialize trajectory variables
    double time = 0;
    Eigen::Vector3d x_d, v_d, a_d;

    // first order filter constant
    double alpha = 0.0;

    try {
        // connect to robot
        franka::Robot robot(argv[1]);

        // load the kinematics and dynamics model
        franka::Model model = robot.loadModel();

        // Read initial configuration
        franka::RobotState initial_state = robot.readOnce();

        // Extract initial endeffector position
        Eigen::Matrix4d T_EE = Eigen::Map<Eigen::Matrix4d>(initial_state.O_T_EE.data());
        const Eigen::Vector3d x0 = T_EE.block<3, 1>(0, 3);

        // Initialize closed loop kinematic variables
        Eigen::Vector3d x = x0;
        Eigen::Vector3d v = {0, 0, 0};

        // Initialize Velocitiy
        franka::CartesianVelocities velocities = {{0.0, 0.0, 0.0, 0.0, 0.0, 0.0}};

        // set collision behavior
        robot.setCollisionBehavior({{100.0, 100.0, 100.0, 100.0, 100.0, 100.0, 100.0}},
                                   {{100.0, 100.0, 100.0, 100.0, 100.0, 100.0, 100.0}},
                                   {{100.0, 100.0, 100.0, 100.0, 100.0, 100.0}},
                                   {{100.0, 100.0, 100.0, 100.0, 100.0, 100.0}});


        // define callback for the torque control loop
        std::function<franka::CartesianVelocities(const franka::RobotState&, franka::Duration)>
            cartesian_velocity_callback = [&] (const franka::RobotState& robot_state, franka::Duration period) -> franka::CartesianVelocities {

            // Compute trajectory (override x_d, v_d, a_d)
            circularTrajectory(time, x0, x_d, v_d, a_d);

            // Read cartesian position
            T_EE = ...
            x = ...

            // Velocity Control (cartesian position level)
            v = ...
            velocities = {{v[0], v[1], v[2], 0.0, 0.0, 0.0}};

            time += period.toSec();

            // Shut down after 5 seconds
            if (time >= 5.0) {
                std::cout << std::endl
                        << "Finished motion, shutting down example" << std::endl;
                return franka::MotionFinished(velocities);
            }

            return velocities;
        };

        std::cout << "Warning: Have the stop button at hand." << std::endl
                  << "Press Enter to move the robot..." << std::endl;
        std::cin.ignore();

        // start real-time control loop
        robot.control(cartesian_velocity_callback);

    } catch (const franka::Exception& ex) {
        // print exception
        std::cout << ex.what() << std::endl;
    }

    return 0;
}
