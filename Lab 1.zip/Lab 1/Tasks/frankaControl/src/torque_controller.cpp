
#include <franka/duration.h>
#include <franka/exception.h>
#include <franka/model.h>
#include <franka/robot.h>

#include <Eigen/Core>
#include <Eigen/Dense>
#include <array>
#include <cmath>
#include <functional>
#include <iostream>

#include "trajectory.h"


int main(int argc, char** argv) {

    // Check whether the required arguments were passed
    if (argc != 2) {
        std::cerr << "Usage: " << argv[0] << " <robot-hostname>" << std::endl;
        return -1;
    }

    // Control Gains
    const double k = ...;
    const double d = 2.0 * sqrt(k); //ciritcal damping behaviour

    Eigen::Matrix3d stiffness, damping;

    stiffness << k, 0, 0,
                 0, k, 0,
                 0, 0, k;

    damping << d, 0, 0,
               0, d, 0,
               0, 0, d;


    // Initialize trajectory variables
    double time = 0;
    Eigen::Vector3d x_d, v_d, a_d;

    try {
        // connect to robot
        franka::Robot robot(argv[1]);

        // load the kinematics and dynamics model
        franka::Model model = robot.loadModel();

        // Read initial configuration
        franka::RobotState initial_state = robot.readOnce();

        // Extract initial endeffector position
        Eigen::Matrix4d T_EE = Eigen::Map<Eigen::Matrix4d>(initial_state.O_T_EE.data());
        const Eigen::Vector3d x0 = T_EE.block<3, 1>(0, 3);

        // Initialize closed loop kinematic variables
        Eigen::Vector3d x = x0;
        Eigen::Vector3d v = {0, 0, 0};
        Eigen::VectorXd q  = Eigen::Map<Eigen::Matrix<double, 7, 1>>(initial_state.q.data());
        Eigen::VectorXd dq = Eigen::Map<Eigen::Matrix<double, 7, 1>>(initial_state.dq.data());

        // Initialize coriolis force
        Eigen::VectorXd coriolis = Eigen::Map<Eigen::Matrix<double, 7, 1>>(model.coriolis(initial_state).data());

        // Initialize jacobian matrix
        Eigen::Matrix<double, 6, 7> jacobian = Eigen::Map<Eigen::Matrix<double, 6, 7>>(model.zeroJacobian(franka::Frame::kEndEffector, initial_state).data());
        Eigen::Matrix<double, 3, 7> jacobian_translation = jacobian.block<3, 7>(0, 0);

        // Initialize Torque (use Eigen object for calculation, franka object for output)
        Eigen::VectorXd tau = coriolis;
        franka::Torques torques = {tau[0], tau[1], tau[2], tau[3], tau[4], tau[5], tau[6]};

        // set collision behavior
        robot.setCollisionBehavior({{100.0, 100.0, 100.0, 100.0, 100.0, 100.0, 100.0}},
                                   {{100.0, 100.0, 100.0, 100.0, 100.0, 100.0, 100.0}},
                                   {{100.0, 100.0, 100.0, 100.0, 100.0, 100.0}},
                                   {{100.0, 100.0, 100.0, 100.0, 100.0, 100.0}});


        // define callback for the torque control loop
        std::function<franka::Torques(const franka::RobotState&, franka::Duration)>
            impedance_control_callback = [&] (const franka::RobotState& robot_state, franka::Duration period) -> franka::Torques {

            // Read joints and velocities
            q  = ...
            dq = ...

            // compute coriolis force
            coriolis = ...

            // Read jacobian and extract translational part
            jacobian = ...
            jacobian_translation = ...

            // Compute trajectory (override x_d, v_d, a_d)
            circularTrajectory(time, x0, x_d, v_d, a_d);

            // Read cartesian position
            T_EE = ...
            x = ...

            // Compute cartesian velocity (v = J*dq)
            v = ...

            // Impedance Control
            tau = ...
            torques = {tau[0], tau[1], tau[2], tau[3], tau[4], tau[5], tau[6]};

            time += period.toSec();

            // Shut down after 5 seconds
            if (time >= 5.0) {
                std::cout << std::endl
                        << "Finished motion, shutting down example" << std::endl;
                return franka::MotionFinished(torques);
            }

            return torques;
        };

        std::cout << "Warning: Have the stop button at hand." << std::endl
                  << "Press Enter to move the robot..." << std::endl;
        std::cin.ignore();

        // start real-time control loop
        robot.control(impedance_control_callback);

    } catch (const franka::Exception& ex) {
        // print exception
        std::cout << ex.what() << std::endl;
    }

    return 0;
}
