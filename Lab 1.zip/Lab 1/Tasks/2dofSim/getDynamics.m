function [M,C,G] = getDynamics(q,dq)

    q1 = q(1);
    q2 = q(2);
    dq1 = dq(1);
    dq2 = dq(2);

    % Model parameters
    m1 = 1.2;
    m2 = 1.2;
    l1 = 1;
    l2 = 1;
    lc1 = 0.5;
    lc2 = 0.5;
    I1 = 0.15;
    I2 = 0.075;
    g = 9.81;
    
    % Model matrices
    M = zeros(2,2);
    M(1,1) = m1*lc1^2 + I1 + m2*(l1^2+lc2^2+2*l1*lc2*cos(q2)) + I2;
    M(1,2) = m2*l1*lc2*cos(q2) + m2*lc2^2 + I2;
    M(2,1) = M(1,2);
    M(2,2) = m2*lc2^2 + I2;
    
    h = m2*l1*lc2*sin(q2);
    C = zeros(2,2);
    C(1,1) = -h*dq2;
    C(1,2) = -h*dq1 - h*dq2;
    C(2,1) = h*dq1;
    
    G = zeros(2,1);
    G(1) = m1*lc1*g*cos(q1) + m2*g*(l2*cos(q1+q2)+l1*cos(q1));
    G(2) = m2*lc2*g*cos(q1+q2);

end