%% Simulation of 2dof system with dynamic controller, 
clear;
close all;
clc;

%% Initialize

% Initial joints
q_init = [3*pi/4; -pi/3; pi/6];

% Initial position
[x0, ~] = getKinematics(q_init);

% Simulation parameters
t_s = 0.001;
t_end = 15;

%% Simulate and display

sim('RobotControl3Dof.slx');

q_robot = squeeze(joint_angles);
if size(q_robot,1)~=2
    q_robot=transpose(q_robot);
end

%% Run animation

figure()

l1=0.5;
l2=0.5;
l3=0.5;

animate_step=0.045/0.001;
color1 = [101,105,112]/255;
color2 = [178,180,183]/255;

j=1;

for i=1:animate_step:size(t,1)
    clf;

    hold on; 
    grid on;
    o=[0;0];
    A=[l1*cos(q_robot(1,i));l1*sin(q_robot(1,i))];
    B=A+[l2*cos(q_robot(1,i)+q_robot(2,i));l2*sin(q_robot(1,i)+q_robot(2,i))]; 
    C=B+[l3*cos(q_robot(1,i)+q_robot(2,i)+q_robot(3,i));l3*sin(q_robot(1,i)+q_robot(2,i)+q_robot(3,i))]; 
    
    line([o(1) A(1)],[o(2) A(2)],'color',color1,'Marker','o','LineWidth',2,'Markersize',4, 'Markerfacecolor',color1);
    line([A(1)  B(1)],[A(2) B(2)],'color',color1,'Marker','o','LineWidth',2,'Markersize',4, 'Markerfacecolor',color1);
    line([B(1)  C(1)],[B(2) C(2)],'color',color1,'Marker','o','LineWidth',2,'Markersize',4, 'Markerfacecolor',color1);

    plot(x_des(:,1),x_des(:,2),'--', 'color',color2)

    axis equal
    axis([-2 2 -1.5  2.5 ])

    j=j+1;
    ff(j)=getframe;
end


