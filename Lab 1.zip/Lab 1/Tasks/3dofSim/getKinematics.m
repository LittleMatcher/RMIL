function [x,J] = getKinematics(q)

q1 = q(1);
q2 = q(2);
q3 = q(3);

l1=0.5;
l2=0.5;
l3=0.5;

x = [l1*cos(q1)+l2*cos(q1+q2)+l3*cos(q1+q2+q3);
     l1*sin(q1)+l2*sin(q1+q2)+l3*sin(q1+q2+q3)];
 
J =[-l1*sin(q1)-l2*sin(q1+q2)-l3*sin(q1+q2+q3), -l2*sin(q1+q2)-l3*sin(q1+q2+q3), -l3*sin(q1+q2+q3);
     l1*cos(q1)+l2*cos(q1+q2)+l3*cos(q1+q2+q3),  l2*cos(q1+q2)+l3*cos(q1+q2+q3),  l3*cos(q1+q2+q3)];

end